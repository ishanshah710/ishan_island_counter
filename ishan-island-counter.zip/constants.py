DIRECTIONS = [
    # Cardinal directions
    (-1, 0), (1, 0), (0, -1), (0, 1), 

    # Diagonal directions 
    (-1, -1), (-1, 1), (1, -1), (1, 1) 
]
